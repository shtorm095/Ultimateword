import UIKit

final class WearMemoryAppDelegate: NSObject, UIApplicationDelegate {
    private static var backgroundCompletionHandler: (() -> Void)?

    func application(
        _ application: UIApplication,
        handleEventsForBackgroundURLSession identifier: String,
        completionHandler: @escaping () -> Void
    ) {
        guard identifier == GoogleDriveSync.backgroundSessionIdentifier else {
            completionHandler()
            return
        }
        Self.backgroundCompletionHandler = completionHandler
    }

    static func finishBackgroundSessionEvents() {
        DispatchQueue.main.async {
            let handler = backgroundCompletionHandler
            backgroundCompletionHandler = nil
            handler?()
        }
    }
}
