import Foundation

/// Passive integration bridge for future WearMemory modules.
/// It never moves/deletes the Audio original, never touches Drive state,
/// and performs all shared-container work on a separate serial queue.
final class AudioIntegrationBridge {
    static let appGroupIdentifier = "group.local.pavel.WearMemory"
    static let bridgeVersion = 1

    struct Status: Codable {
        let bridgeVersion: Int
        let module: String
        let appVersion: String
        let build: String
        let isRecording: Bool
        let audioStatus: String
        let driveStatus: String
        let drivePendingCount: Int
        let driveLastError: String?
        let lastCompletedAudioFile: String?
        let lastCompletedAt: Date?
        let updatedAt: Date
    }

    private struct AudioMetadata: Codable {
        let bridgeVersion: Int
        let sourceFileName: String
        let startedAt: Date
        let endedAt: Date
        let exportedAt: Date
    }

    private let fm = FileManager.default
    private let queue = DispatchQueue(label: "WearMemory.Audio.IntegrationBridge", qos: .utility)
    private let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.outputFormatting = [.sortedKeys]
        e.dateEncodingStrategy = .iso8601
        return e
    }()

    func exportFinalizedAudio(_ sourceURL: URL, startedAt: Date, endedAt: Date) {
        queue.async { [weak self] in
            self?.performExport(sourceURL, startedAt: startedAt, endedAt: endedAt)
        }
    }

    func publishStatus(_ status: Status) {
        queue.async { [weak self] in
            guard let self = self else { return }
            do {
                let root = try self.sharedRoot()
                let dir = root.appendingPathComponent("Status", isDirectory: true)
                try self.fm.createDirectory(at: dir, withIntermediateDirectories: true)
                try self.encoder.encode(status).write(to: dir.appendingPathComponent("audio.json"), options: .atomic)
            } catch {
                NSLog("WearMemory Audio status bridge: %@", error.localizedDescription)
            }
        }
    }

    private func performExport(_ sourceURL: URL, startedAt: Date, endedAt: Date) {
        do {
            guard fm.fileExists(atPath: sourceURL.path) else {
                throw NSError(domain: "WearMemory.AudioIntegrationBridge", code: 2,
                              userInfo: [NSLocalizedDescriptionKey: "Finalized audio file not found"])
            }
            let size = (try? sourceURL.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
            guard size > 0 else {
                throw NSError(domain: "WearMemory.AudioIntegrationBridge", code: 3,
                              userInfo: [NSLocalizedDescriptionKey: "Finalized audio file is empty"])
            }

            let root = try sharedRoot()
            let inbox = root.appendingPathComponent("AudioInbox", isDirectory: true)
            try fm.createDirectory(at: inbox, withIntermediateDirectories: true)
            let destination = inbox.appendingPathComponent(sourceURL.lastPathComponent)
            if !fm.fileExists(atPath: destination.path) {
                let temp = inbox.appendingPathComponent(".incoming-\(UUID().uuidString)-\(sourceURL.lastPathComponent)")
                try fm.copyItem(at: sourceURL, to: temp)
                try fm.moveItem(at: temp, to: destination)
            }

            let metadata = AudioMetadata(
                bridgeVersion: Self.bridgeVersion,
                sourceFileName: sourceURL.lastPathComponent,
                startedAt: startedAt,
                endedAt: endedAt,
                exportedAt: Date()
            )
            let sidecar = inbox.appendingPathComponent(sourceURL.deletingPathExtension().lastPathComponent + ".meta.json")
            try encoder.encode(metadata).write(to: sidecar, options: .atomic)
        } catch {
            NSLog("WearMemory Audio integration bridge: %@", error.localizedDescription)
        }
    }

    private func sharedRoot() throws -> URL {
        guard let root = fm.containerURL(forSecurityApplicationGroupIdentifier: Self.appGroupIdentifier) else {
            throw NSError(domain: "WearMemory.AudioIntegrationBridge", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "App Group container unavailable"])
        }
        return root
    }
}
