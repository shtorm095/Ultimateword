import SwiftUI

@main
struct WearMemoryApp: App {
    @UIApplicationDelegateAdaptor(WearMemoryAppDelegate.self) private var appDelegate
    @StateObject private var model = AppModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .onOpenURL { url in
                    _ = model.driveSync.handleOpenURL(url)
                }
                .onChange(of: scenePhase) { phase in
                    if phase == .active {
                        model.driveSync.flushQueue()
                    }
                }
        }
    }
}
