import Foundation

final class DailyLogStore: ObservableObject {
    @Published private(set) var entries: [TranscriptEntry] = []

    // Called whenever the daily TXT changes. AppModel uses this to mirror the file
    // to the user-selected external folder (Google Drive → Audio Lesen).
    var onTextFileUpdated: ((URL) -> Void)?

    private let fm = FileManager.default
    private let calendar = Calendar.current
    private let jsonEncoder: JSONEncoder = {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .iso8601
        return e
    }()
    private let jsonDecoder: JSONDecoder = {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        return d
    }()

    init() {
        try? fm.createDirectory(at: logsDirectory, withIntermediateDirectories: true)
        loadToday()
    }

    var logsDirectory: URL {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("Logs", isDirectory: true)
    }

    func append(_ entry: TranscriptEntry) {
        DispatchQueue.main.async {
            self.entries.append(entry)
            self.entries.sort { $0.startedAt < $1.startedAt }
            self.persistToday()
            self.appendToTextFile(entry)
            self.onTextFileUpdated?(self.textURL(for: entry.startedAt))
        }
    }

    func entries(since date: Date) -> [TranscriptEntry] {
        entries.filter { $0.endedAt >= date }
    }

    func text(since date: Date) -> String {
        entries(since: date).map(format).joined(separator: "\n")
    }

    func todayText() -> String {
        entries.map(format).joined(separator: "\n")
    }

    func todayTextURL() -> URL {
        textURL(for: Date())
    }

    func appendMediaReference(kind: String, url: URL, at date: Date = Date()) {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "HH:mm:ss"

        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let relative = url.path.replacingOccurrences(of: docs.path + "/", with: "")
        let line = "[\(f.string(from: date))] [\(kind)] \(relative)\n"

        let target = textURL(for: date)
        guard let data = line.data(using: .utf8) else { return }

        if fm.fileExists(atPath: target.path), let handle = try? FileHandle(forWritingTo: target) {
            defer { try? handle.close() }
            try? handle.seekToEnd()
            try? handle.write(contentsOf: data)
        } else {
            try? data.write(to: target, options: .atomic)
        }
        onTextFileUpdated?(target)
    }

    func reloadIfDayChanged() {
        let today = dayKey(Date())
        let entryDay = entries.last.map { dayKey($0.startedAt) }
        if entryDay != nil && entryDay != today {
            entries = []
            loadToday()
        }
    }

    private func loadToday() {
        let url = jsonURL(for: Date())
        guard let data = try? Data(contentsOf: url),
              let decoded = try? jsonDecoder.decode([TranscriptEntry].self, from: data) else {
            entries = []
            return
        }
        entries = decoded.sorted { $0.startedAt < $1.startedAt }
    }

    private func persistToday() {
        let url = jsonURL(for: Date())
        guard let data = try? jsonEncoder.encode(entries) else { return }
        try? data.write(to: url, options: .atomic)
    }

    private func appendToTextFile(_ entry: TranscriptEntry) {
        let url = textURL(for: entry.startedAt)
        let line = format(entry) + "\n"
        guard let data = line.data(using: .utf8) else { return }

        if fm.fileExists(atPath: url.path), let handle = try? FileHandle(forWritingTo: url) {
            defer { try? handle.close() }
            try? handle.seekToEnd()
            try? handle.write(contentsOf: data)
        } else {
            try? data.write(to: url, options: .atomic)
        }
    }

    private func format(_ entry: TranscriptEntry) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "HH:mm:ss"
        return "[\(f.string(from: entry.startedAt))] \(entry.text)"
    }

    private func dayKey(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }

    private func jsonURL(for date: Date) -> URL {
        logsDirectory.appendingPathComponent("\(dayKey(date)).json")
    }

    private func textURL(for date: Date) -> URL {
        logsDirectory.appendingPathComponent("\(dayKey(date)).txt")
    }
}
