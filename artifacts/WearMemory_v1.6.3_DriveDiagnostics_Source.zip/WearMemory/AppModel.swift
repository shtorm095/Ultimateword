import Foundation
import UIKit
import Combine

final class AppModel: ObservableObject {
    @Published var language: TranscriptionLanguage = .russian {
        didSet { transcription.language = language }
    }
    @Published var transcriptionEnabled = true {
        didSet { audio.transcribeSegments = transcriptionEnabled }
    }
    @Published var onDeviceOnly = false {
        didSet { transcription.onDeviceOnly = onDeviceOnly }
    }
    @Published private(set) var batteryLevel: Float = -1
    let audio = AudioBufferManager()
    let transcription = TranscriptionService()
    let logs = DailyLogStore()
    let media = MediaStore()
    let externalTextFolder = ExternalTextFolderStore()
    let externalAudioFolder = ExternalAudioFolderStore()
    var driveSync = GoogleDriveSync()

    private var batteryObserver: NSObjectProtocol?
    private var cancellables = Set<AnyCancellable>()

    init() {
        audio.objectWillChange
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.objectWillChange.send() }
            .store(in: &cancellables)

        transcription.onTranscript = { [weak self] entry in
            self?.logs.append(entry)
        }
        logs.onTextFileUpdated = { [weak self] url in
            self?.driveSync.enqueueText(url)
        }
        transcription.language = language
        transcription.onDeviceOnly = onDeviceOnly
        audio.transcribeSegments = transcriptionEnabled
        audio.onSegmentCompleted = { [weak self] url, _, _ in
            self?.driveSync.enqueueAudio(url)
        }
        audio.onSegmentReady = { [weak self] url, start, end in
            self?.logs.reloadIfDayChanged()
            self?.transcription.enqueue(url: url, startedAt: start, endedAt: end)
        }

        UIDevice.current.isBatteryMonitoringEnabled = true
        batteryLevel = UIDevice.current.batteryLevel
        batteryObserver = NotificationCenter.default.addObserver(
            forName: UIDevice.batteryLevelDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.batteryLevel = UIDevice.current.batteryLevel
        }
    }

    deinit {
        if let o = batteryObserver { NotificationCenter.default.removeObserver(o) }
    }

    func beginMediaCapture() {
        // Photo and silent video do not use the microphone.
        // Keep the 24-hour audio recorder running.
    }

    func endMediaCaptureWithoutSave() {
        // Nothing to resume: audio recording was never stopped.
    }

    func savePendingMedia(_ pending: PendingMedia) throws -> URL {
        let saved: URL
        switch pending {
        case .photo(let image):
            saved = try media.savePhoto(image)
            logs.appendMediaReference(kind: "ФОТО", url: saved)

        case .video(let url):
            saved = try media.saveVideo(from: url)
            media.discardTemporaryVideo(url)
            logs.appendMediaReference(kind: "ВИДЕО-БЕЗ-ЗВУКА", url: saved)
        }
        return saved
    }

    func discardPendingMedia(_ pending: PendingMedia) {
        if case .video(let url) = pending {
            media.discardTemporaryVideo(url)
        }
    }

    func selectAudioLesenFolder(_ url: URL) throws {
        try externalTextFolder.selectFolder(url)
        let today = logs.todayTextURL()
        if FileManager.default.fileExists(atPath: today.path) {
            externalTextFolder.syncTextFile(today)
        }
    }

    func selectAudioHoerenFolder(_ url: URL) throws {
        try externalAudioFolder.selectFolder(url)
    }

    func requestPermissions() {
        audio.requestMicPermission { _ in }
        transcription.requestAuthorization()
    }

    func last24HoursText() -> String {
        logs.text(since: Date().addingTimeInterval(-24 * 60 * 60))
    }

    func copyLast24HoursAndOpenChatGPT() {
        let text = last24HoursText()
        UIPasteboard.general.string = text.isEmpty ? "[За последние 24 часа распознанного текста нет]" : text
        audio.pauseForExternalVoice()
        if let url = URL(string: "https://chatgpt.com/") {
            UIApplication.shared.open(url)
        }
    }

    func copyToday() {
        UIPasteboard.general.string = logs.todayText()
    }
}
