import Foundation
import UIKit

final class MediaStore: ObservableObject {
    @Published private(set) var lastSavedURL: URL?

    private let fm = FileManager.default

    var mediaDirectory: URL {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("Media", isDirectory: true)
    }

    init() {
        try? fm.createDirectory(at: mediaDirectory, withIntermediateDirectories: true)
    }

    func savePhoto(_ image: UIImage, at date: Date = Date()) throws -> URL {
        let dayDir = try dayDirectory(for: date)
        let url = dayDir.appendingPathComponent("photo-\(timestamp(date)).jpg")

        guard let data = image.jpegData(compressionQuality: 0.92) else {
            throw NSError(
                domain: "WearMemory.Media",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "Не удалось преобразовать фото в JPEG"]
            )
        }

        try data.write(to: url, options: .atomic)
        DispatchQueue.main.async { self.lastSavedURL = url }
        return url
    }

    func saveVideo(from temporaryURL: URL, at date: Date = Date()) throws -> URL {
        let dayDir = try dayDirectory(for: date)
        let ext = temporaryURL.pathExtension.isEmpty ? "mov" : temporaryURL.pathExtension
        let url = dayDir.appendingPathComponent("video-\(timestamp(date)).\(ext)")

        if fm.fileExists(atPath: url.path) {
            try fm.removeItem(at: url)
        }
        try fm.copyItem(at: temporaryURL, to: url)
        DispatchQueue.main.async { self.lastSavedURL = url }
        return url
    }

    func discardTemporaryVideo(_ url: URL) {
        // UIImagePickerController normally gives a temporary URL.
        // Delete only files located in the system temporary directory.
        let tmp = fm.temporaryDirectory.standardizedFileURL.path
        let candidate = url.standardizedFileURL.path
        if candidate.hasPrefix(tmp) {
            try? fm.removeItem(at: url)
        }
    }

    private func dayDirectory(for date: Date) throws -> URL {
        let url = mediaDirectory.appendingPathComponent(dayKey(date), isDirectory: true)
        try fm.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    private func dayKey(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }

    private func timestamp(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd-HHmmss"
        return f.string(from: date)
    }
}
