import Foundation
import UIKit

struct TranscriptEntry: Codable, Identifiable, Equatable {
    let id: UUID
    let startedAt: Date
    let endedAt: Date
    let text: String
    let sourceFile: String

    init(id: UUID = UUID(), startedAt: Date, endedAt: Date, text: String, sourceFile: String) {
        self.id = id
        self.startedAt = startedAt
        self.endedAt = endedAt
        self.text = text
        self.sourceFile = sourceFile
    }
}

enum TranscriptionLanguage: String, CaseIterable, Identifiable {
    case russian = "ru-RU"
    case german = "de-DE"
    case english = "en-US"

    var id: String { rawValue }

    var title: String {
        switch self {
        case .russian: return "Русский"
        case .german: return "Deutsch"
        case .english: return "English"
        }
    }
}


enum MediaCaptureMode: String, Identifiable {
    case photo
    case video

    var id: String { rawValue }

    var title: String {
        switch self {
        case .photo: return "Фото"
        case .video: return "Видео"
        }
    }
}

enum PendingMedia {
    case photo(UIImage)
    case video(URL)
}
