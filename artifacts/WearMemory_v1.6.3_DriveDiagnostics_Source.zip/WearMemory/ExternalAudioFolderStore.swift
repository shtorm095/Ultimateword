import Foundation

final class ExternalAudioFolderStore: ObservableObject {
    @Published private(set) var selectedFolderName: String?
    @Published private(set) var statusText = "Папка Audio Hören не выбрана"
    @Published private(set) var lastSyncDate: Date?

    private let bookmarkKey = "WearMemory.AudioHoerenFolderBookmark"
    private let defaults = UserDefaults.standard
    private let expectedFolderName = "Audio Hören"
    private let queue = DispatchQueue(label: "WearMemory.ExternalAudioFolderStore", qos: .utility)

    init() {
        refreshStatusFromBookmark()
    }

    var isConfigured: Bool { selectedFolderName != nil }

    func selectFolder(_ url: URL) throws {
        guard url.lastPathComponent == expectedFolderName else {
            throw FolderError.wrongFolder(url.lastPathComponent)
        }

        guard url.startAccessingSecurityScopedResource() else {
            throw FolderError.accessDenied
        }
        defer { url.stopAccessingSecurityScopedResource() }

        let bookmark = try url.bookmarkData(
            options: .minimalBookmark,
            includingResourceValuesForKeys: nil,
            relativeTo: nil
        )
        defaults.set(bookmark, forKey: bookmarkKey)

        DispatchQueue.main.async {
            self.selectedFolderName = self.expectedFolderName
            self.statusText = "Аудио → Audio Hören"
        }
    }

    func clearFolder() {
        defaults.removeObject(forKey: bookmarkKey)
        DispatchQueue.main.async {
            self.selectedFolderName = nil
            self.statusText = "Папка Audio Hören не выбрана"
            self.lastSyncDate = nil
        }
    }

    func syncAudioFile(_ sourceURL: URL) {
        queue.async { [weak self] in
            self?.performSync(sourceURL)
        }
    }

    private func performSync(_ sourceURL: URL) {
        do {
            let folderURL = try resolveFolderURL()
            guard folderURL.startAccessingSecurityScopedResource() else {
                throw FolderError.accessDenied
            }
            defer { folderURL.stopAccessingSecurityScopedResource() }

            let destinationName = sourceURL.lastPathComponent
            var coordinationError: NSError?
            var operationError: Error?

            NSFileCoordinator().coordinate(
                writingItemAt: folderURL,
                options: [],
                error: &coordinationError
            ) { coordinatedFolderURL in
                do {
                    let destination = coordinatedFolderURL.appendingPathComponent(destinationName, isDirectory: false)
                    let data = try Data(contentsOf: sourceURL)
                    try data.write(to: destination, options: .atomic)
                } catch {
                    operationError = error
                }
            }

            if let error = coordinationError { throw error }
            if let error = operationError { throw error }

            DispatchQueue.main.async {
                self.lastSyncDate = Date()
                self.statusText = "Аудио → Audio Hören · сохранено"
            }
        } catch {
            DispatchQueue.main.async {
                self.statusText = "Audio Hören: нет доступа — локальная копия сохранена"
            }
        }
    }

    private func resolveFolderURL() throws -> URL {
        guard let data = defaults.data(forKey: bookmarkKey) else {
            throw FolderError.notConfigured
        }

        var stale = false
        let url = try URL(
            resolvingBookmarkData: data,
            options: [.withoutUI],
            relativeTo: nil,
            bookmarkDataIsStale: &stale
        )

        if stale {
            throw FolderError.staleBookmark
        }
        return url
    }

    private func refreshStatusFromBookmark() {
        guard defaults.data(forKey: bookmarkKey) != nil else {
            selectedFolderName = nil
            statusText = "Папка Audio Hören не выбрана"
            return
        }

        do {
            let url = try resolveFolderURL()
            if url.lastPathComponent == expectedFolderName {
                selectedFolderName = expectedFolderName
                statusText = "Аудио → Audio Hören"
            } else {
                clearFolder()
            }
        } catch {
            selectedFolderName = nil
            statusText = "Audio Hören нужно выбрать снова"
        }
    }

    enum FolderError: LocalizedError {
        case wrongFolder(String)
        case accessDenied
        case notConfigured
        case staleBookmark

        var errorDescription: String? {
            switch self {
            case .wrongFolder(let name):
                return "Выбрана папка «\(name)». Нужно выбрать «Audio Hören»."
            case .accessDenied:
                return "iOS не дал доступ к выбранной папке."
            case .notConfigured:
                return "Папка Audio Hören ещё не выбрана."
            case .staleBookmark:
                return "Доступ к папке устарел. Выберите Audio Hören ещё раз."
            }
        }
    }
}
