import Foundation
import Speech
import AVFoundation

final class TranscriptionService: ObservableObject {
    @Published private(set) var authorization: SFSpeechRecognizerAuthorizationStatus = .notDetermined
    @Published private(set) var statusText: String = "Не запущено"
    @Published private(set) var supportsOnDevice = false

    var language: TranscriptionLanguage = .russian {
        didSet { refreshCapabilities() }
    }
    var onDeviceOnly = false

    private var queue: [(url: URL, startedAt: Date, endedAt: Date)] = []
    private var isProcessing = false
    private let lock = NSLock()
    private var currentTask: SFSpeechRecognitionTask?
    var onTranscript: ((TranscriptEntry) -> Void)?

    init() {
        authorization = SFSpeechRecognizer.authorizationStatus()
        refreshCapabilities()
    }

    func requestAuthorization() {
        SFSpeechRecognizer.requestAuthorization { [weak self] status in
            DispatchQueue.main.async {
                self?.authorization = status
                self?.refreshCapabilities()
            }
        }
    }

    func enqueue(url: URL, startedAt: Date, endedAt: Date) {
        lock.lock()
        queue.append((url, startedAt, endedAt))
        let shouldStart = !isProcessing
        if shouldStart { isProcessing = true }
        lock.unlock()

        if shouldStart { processNextStorageChunk() }
    }

    private func processNextStorageChunk() {
        lock.lock()
        guard !queue.isEmpty else {
            isProcessing = false
            lock.unlock()
            DispatchQueue.main.async { self.statusText = "Ожидание речи" }
            return
        }
        let item = queue.removeFirst()
        lock.unlock()

        guard authorization == .authorized else {
            DispatchQueue.main.async { self.statusText = "Нет разрешения Speech" }
            processNextStorageChunk()
            return
        }

        splitIntoOneMinutePieces(
            sourceURL: item.url,
            chunkStartedAt: item.startedAt
        ) { [weak self] pieces in
            guard let self = self else { return }
            self.recognizePieces(pieces, index: 0) {
                self.processNextStorageChunk()
            }
        }
    }

    private func splitIntoOneMinutePieces(
        sourceURL: URL,
        chunkStartedAt: Date,
        completion: @escaping ([(URL, Date, Date)]) -> Void
    ) {
        let asset = AVURLAsset(url: sourceURL)
        let duration = CMTimeGetSeconds(asset.duration)
        guard duration.isFinite, duration > 0 else {
            completion([])
            return
        }

        let fm = FileManager.default
        let tempDir = fm.temporaryDirectory
            .appendingPathComponent("WearMemorySpeech", isDirectory: true)
        try? fm.createDirectory(at: tempDir, withIntermediateDirectories: true)

        var pieces: [(URL, Date, Date)] = []
        let group = DispatchGroup()
        let sync = DispatchQueue(label: "WearMemory.TranscriptionPieces")

        var start: Double = 0
        var part = 0

        while start < duration {
            let len = min(60.0, duration - start)
            let pieceStart = chunkStartedAt.addingTimeInterval(start)
            let pieceEnd = pieceStart.addingTimeInterval(len)
            let outURL = tempDir.appendingPathComponent(
                "\(UUID().uuidString)_\(part).m4a"
            )

            guard let exporter = AVAssetExportSession(
                asset: asset,
                presetName: AVAssetExportPresetAppleM4A
            ) else {
                start += len
                part += 1
                continue
            }

            exporter.outputURL = outURL
            exporter.outputFileType = .m4a
            exporter.timeRange = CMTimeRange(
                start: CMTime(seconds: start, preferredTimescale: 600),
                duration: CMTime(seconds: len, preferredTimescale: 600)
            )

            group.enter()
            exporter.exportAsynchronously {
                if exporter.status == .completed {
                    sync.sync {
                        pieces.append((outURL, pieceStart, pieceEnd))
                    }
                }
                group.leave()
            }

            start += len
            part += 1
        }

        group.notify(queue: .global(qos: .utility)) {
            let sorted = pieces.sorted { $0.1 < $1.1 }
            completion(sorted)
        }
    }

    private func recognizePieces(
        _ pieces: [(URL, Date, Date)],
        index: Int,
        completion: @escaping () -> Void
    ) {
        guard index < pieces.count else {
            for piece in pieces { try? FileManager.default.removeItem(at: piece.0) }
            completion()
            return
        }

        let piece = pieces[index]

        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: language.rawValue)),
              recognizer.isAvailable else {
            DispatchQueue.main.async { self.statusText = "Распознавание недоступно" }
            recognizePieces(pieces, index: index + 1, completion: completion)
            return
        }

        let canOnDevice = recognizer.supportsOnDeviceRecognition
        DispatchQueue.main.async { self.supportsOnDevice = canOnDevice }

        if onDeviceOnly && !canOnDevice {
            DispatchQueue.main.async { self.statusText = "Локальное распознавание не поддерживается" }
            recognizePieces(pieces, index: index + 1, completion: completion)
            return
        }

        let request = SFSpeechURLRecognitionRequest(url: piece.0)
        request.shouldReportPartialResults = false
        if #available(iOS 13.0, *) {
            request.requiresOnDeviceRecognition = onDeviceOnly && canOnDevice
        }

        DispatchQueue.main.async {
            self.statusText = "Распознаю 60-сек. часть…"
        }

        var completed = false
        func finishOne() {
            guard !completed else { return }
            completed = true
            self.currentTask?.cancel()
            self.currentTask = nil
            try? FileManager.default.removeItem(at: piece.0)
            self.recognizePieces(pieces, index: index + 1, completion: completion)
        }

        currentTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
            guard let self = self else { return }

            if let result = result, result.isFinal {
                let text = result.bestTranscription.formattedString
                    .trimmingCharacters(in: .whitespacesAndNewlines)

                if !text.isEmpty {
                    let entry = TranscriptEntry(
                        startedAt: piece.1,
                        endedAt: piece.2,
                        text: text,
                        sourceFile: sourceURLName(from: piece.0)
                    )
                    DispatchQueue.main.async { self.onTranscript?(entry) }
                }
                finishOne()
                return
            }

            if error != nil {
                DispatchQueue.main.async { self.statusText = "Speech: часть пропущена" }
                finishOne()
            }
        }
    }

    private func sourceURLName(from url: URL) -> String {
        url.lastPathComponent
    }

    private func refreshCapabilities() {
        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: language.rawValue)) else {
            DispatchQueue.main.async { self.supportsOnDevice = false }
            return
        }
        DispatchQueue.main.async { self.supportsOnDevice = recognizer.supportsOnDeviceRecognition }
    }
}
