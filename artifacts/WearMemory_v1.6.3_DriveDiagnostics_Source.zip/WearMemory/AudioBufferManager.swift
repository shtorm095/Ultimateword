import Foundation
import AVFoundation
import UIKit

final class AudioBufferManager: NSObject, ObservableObject, AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    @Published private(set) var isRecording = false
    @Published private(set) var statusText = "Остановлено"
    @Published private(set) var inputName = "—"
    @Published private(set) var segmentCount = 0
    @Published private(set) var bufferBytes: Int64 = 0
    @Published private(set) var recentSegments: [AudioSegmentSummary] = []
    @Published private(set) var playingURL: URL?

    var segmentDuration: TimeInterval = 3 * 60
    var maxSegments = 480
    var transcribeSegments = true

    var onSegmentReady: ((URL, Date, Date) -> Void)?
    var onSegmentCompleted: ((URL, Date, Date) -> Void)?

    private let fm = FileManager.default
    private var recorder: AVAudioRecorder?
    private var player: AVAudioPlayer?
    private var currentStart: Date?
    private var shouldContinue = false
    private var interruptionObserver: NSObjectProtocol?
    private var routeObserver: NSObjectProtocol?

    override init() {
        super.init()
        try? fm.createDirectory(at: bufferDirectory, withIntermediateDirectories: true)
        pruneBuffer()
        refreshStats()

        interruptionObserver = NotificationCenter.default.addObserver(
            forName: AVAudioSession.interruptionNotification,
            object: nil,
            queue: .main
        ) { [weak self] note in self?.handleInterruption(note) }

        routeObserver = NotificationCenter.default.addObserver(
            forName: AVAudioSession.routeChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in self?.updateInputName() }
    }

    deinit {
        if let o = interruptionObserver { NotificationCenter.default.removeObserver(o) }
        if let o = routeObserver { NotificationCenter.default.removeObserver(o) }
    }

    var bufferDirectory: URL {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("AudioBuffer", isDirectory: true)
    }

    func requestMicPermission(completion: @escaping (Bool) -> Void) {
        AVAudioSession.sharedInstance().requestRecordPermission { granted in
            DispatchQueue.main.async { completion(granted) }
        }
    }

    func start() {
        stopPlayback()
        requestMicPermission { [weak self] granted in
            guard let self = self else { return }
            guard granted else {
                self.statusText = "Нет доступа к микрофону"
                return
            }
            self.shouldContinue = true
            do {
                try self.configureSession()
                try self.startNewSegment()
            } catch {
                self.statusText = "Ошибка аудио: \(error.localizedDescription)"
                self.shouldContinue = false
            }
        }
    }

    func stop() {
        shouldContinue = false
        guard let activeRecorder = recorder else {
            isRecording = false
            statusText = "Остановлено"
            if player == nil {
                try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
            }
            return
        }

        // Keep the recorder alive until AVAudioRecorderDelegate confirms that the file has
        // been finalized. The completed callback is what queues the M4A for Google Drive.
        activeRecorder.stop()
        isRecording = false
        statusText = "Остановлено"
    }

    func togglePlayback(_ url: URL) {
        let normalized = url.standardizedFileURL
        if let playingURL = playingURL?.standardizedFileURL,
           playingURL == normalized,
           player?.isPlaying == true {
            stopPlayback()
            return
        }

        stopPlayback()

        do {
            let session = AVAudioSession.sharedInstance()
            if !isRecording {
                try session.setCategory(.playback, mode: .default, options: [])
                try session.setActive(true, options: [])
            }

            let newPlayer = try AVAudioPlayer(contentsOf: normalized)
            newPlayer.delegate = self
            newPlayer.prepareToPlay()
            guard newPlayer.play() else {
                throw NSError(domain: "WearMemory", code: 2, userInfo: [NSLocalizedDescriptionKey: "Не удалось начать воспроизведение"])
            }
            player = newPlayer
            playingURL = normalized
        } catch {
            player = nil
            playingURL = nil
            if !isRecording {
                try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
            }
        }
    }

    func stopPlayback() {
        player?.stop()
        player = nil
        playingURL = nil
        if !isRecording {
            try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        }
    }

    func isPlaying(_ url: URL) -> Bool {
        guard player?.isPlaying == true, let playingURL = playingURL else { return false }
        return playingURL.standardizedFileURL == url.standardizedFileURL
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        self.player = nil
        playingURL = nil
        if !isRecording {
            try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
        }
    }

    func pauseForExternalVoice() {
        stop()
    }

    private func configureSession() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .default, options: [.allowBluetooth])
        try session.setActive(true, options: [])
        updateInputName()
    }

    private func startNewSegment() throws {
        guard shouldContinue else { return }
        pruneBuffer()

        let now = Date()
        currentStart = now
        let url = bufferDirectory.appendingPathComponent(fileName(for: now))

        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 16_000,
            AVNumberOfChannelsKey: 1,
            AVEncoderBitRateKey: 32_000,
            AVEncoderAudioQualityKey: AVAudioQuality.medium.rawValue
        ]

        let newRecorder = try AVAudioRecorder(url: url, settings: settings)
        newRecorder.delegate = self
        newRecorder.prepareToRecord()
        guard newRecorder.record(forDuration: segmentDuration) else {
            throw NSError(domain: "WearMemory", code: 1, userInfo: [NSLocalizedDescriptionKey: "Не удалось начать запись"])
        }

        recorder = newRecorder
        isRecording = true
        statusText = "Запись"
        refreshStats()
    }

    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        let end = Date()
        let start = currentStart ?? end.addingTimeInterval(-segmentDuration)
        let url = recorder.url

        // The just-finished file is no longer active, so make it visible in the file list and
        // keep the delegate callback alive long enough for Drive/transcription consumers.
        if self.recorder === recorder {
            self.recorder = nil
        }
        currentStart = nil

        if flag {
            onSegmentCompleted?(url, start, end)
            if transcribeSegments {
                onSegmentReady?(url, start, end)
            }
        }

        pruneBuffer()
        refreshStats()

        guard shouldContinue else {
            isRecording = false
            statusText = "Остановлено"
            if player == nil {
                try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
            }
            return
        }

        do {
            try startNewSegment()
        } catch {
            shouldContinue = false
            isRecording = false
            statusText = "Ошибка: \(error.localizedDescription)"
        }
    }

    private func handleInterruption(_ note: Notification) {
        guard let info = note.userInfo,
              let raw = info[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }

        switch type {
        case .began:
            statusText = "Аудио прервано системой"
        case .ended:
            if shouldContinue {
                do {
                    try configureSession()
                    try startNewSegment()
                } catch {
                    statusText = "Не удалось возобновить запись"
                }
            }
        @unknown default:
            break
        }
    }

    private func updateInputName() {
        let route = AVAudioSession.sharedInstance().currentRoute
        DispatchQueue.main.async {
            self.inputName = route.inputs.first?.portName ?? "Встроенный микрофон"
        }
    }

    private func pruneBuffer() {
        guard let urls = try? fm.contentsOfDirectory(
            at: bufferDirectory,
            includingPropertiesForKeys: [.creationDateKey, .fileSizeKey],
            options: [.skipsHiddenFiles]
        ) else { return }

        let sorted = urls.sorted { a, b in
            let da = (try? a.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? .distantPast
            let db = (try? b.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? .distantPast
            return da < db
        }

        let excess = max(0, sorted.count - maxSegments)
        if excess > 0 {
            for url in sorted.prefix(excess) { try? fm.removeItem(at: url) }
        }
    }

    private func refreshStats() {
        guard let urls = try? fm.contentsOfDirectory(
            at: bufferDirectory,
            includingPropertiesForKeys: [.fileSizeKey, .creationDateKey],
            options: [.skipsHiddenFiles]
        ) else { return }

        var bytes: Int64 = 0
        var summaries: [AudioSegmentSummary] = []
        let activeURL = recorder?.url.standardizedFileURL

        for url in urls {
            let values = try? url.resourceValues(forKeys: [.fileSizeKey, .creationDateKey])
            let size = Int64(values?.fileSize ?? 0)
            bytes += size

            if url.standardizedFileURL != activeURL {
                let asset = AVURLAsset(url: url)
                let duration = CMTimeGetSeconds(asset.duration)
                summaries.append(
                    AudioSegmentSummary(
                        url: url,
                        createdAt: values?.creationDate ?? .distantPast,
                        duration: duration.isFinite ? duration : 0,
                        sizeBytes: size
                    )
                )
            }
        }

        summaries.sort { $0.createdAt > $1.createdAt }

        DispatchQueue.main.async {
            self.segmentCount = urls.count
            self.bufferBytes = bytes
            self.recentSegments = Array(summaries.prefix(12))
        }
    }

    private func fileName(for date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd-HHmmss"
        return "audio-\(f.string(from: date)).m4a"
    }
}


struct AudioSegmentSummary: Identifiable, Equatable {
    let url: URL
    let createdAt: Date
    let duration: TimeInterval
    let sizeBytes: Int64

    var id: String { url.path }
    var fileName: String { url.lastPathComponent }
}
