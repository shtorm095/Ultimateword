import SwiftUI

@main
struct WearMemoryApp: App {
    @StateObject private var model = AppModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .onOpenURL { url in
                    _ = model.driveSync.handleOpenURL(url)
                }
        }
    }
}
