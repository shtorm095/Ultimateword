import SwiftUI
import AVKit

struct MediaConfirmationView: View {
    let media: PendingMedia
    let onSave: () -> Void
    let onDiscard: () -> Void

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                preview
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

                Text("Сохранить этот материал?")
                    .font(.headline)

                HStack(spacing: 14) {
                    Button(role: .destructive) {
                        onDiscard()
                    } label: {
                        Text("Удалить")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)

                    Button {
                        onSave()
                    } label: {
                        Text("Сохранить")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    @ViewBuilder
    private var preview: some View {
        switch media {
        case .photo(let image):
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .background(Color.black)

        case .video(let url):
            VideoPlayer(player: AVPlayer(url: url))
        }
    }

    private var title: String {
        switch media {
        case .photo: return "Проверка фото"
        case .video: return "Проверка видео"
        }
    }
}
