import Foundation
import CryptoKit
import Security
import Network
import UIKit

final class GoogleDriveSync: NSObject, ObservableObject {
    static let clientID = "923188036776-mos9ub27f4k3bhnodr8r4n46flsisptj.apps.googleusercontent.com"
    static let callbackScheme = "com.googleusercontent.apps.923188036776-mos9ub27f4k3bhnodr8r4n46flsisptj"
    static let redirectURI = callbackScheme + ":/oauth2redirect"
    // Google Picker desktop/mobile flow: only drive.file is permitted. The user explicitly
    // grants this app access to the two pre-existing target folders during OAuth.
    static let scope = "https://www.googleapis.com/auth/drive.file"

    static let textFolderID = "12ACQobm9LRdmmgPixarKN_trU55GiwXs"
    static let audioFolderID = "1DxRqc1GP6TeSmRM0IhORnXzksZopWIj2"

    @Published var syncEnabled: Bool = UserDefaults.standard.object(forKey: "drive.oauth.syncEnabled") as? Bool ?? true {
        didSet {
            UserDefaults.standard.set(syncEnabled, forKey: "drive.oauth.syncEnabled")
            if syncEnabled { flushQueue() }
        }
    }
    @Published private(set) var isAuthorized = false
    @Published private(set) var foldersAuthorized = false
    @Published private(set) var statusText = "Не подключено"
    @Published private(set) var pendingCount = 0
    @Published private(set) var lastError: String?

    private let fm = FileManager.default
    private let defaults = UserDefaults.standard
    private let monitor = NWPathMonitor()
    private let monitorQueue = DispatchQueue(label: "WearMemory.GoogleDrive.Network")
    private let workQueue = DispatchQueue(label: "WearMemory.GoogleDrive.Work")

    private var currentVerifier: String?
    private var currentState: String?
    private var isFlushing = false

    private var accessToken: String?
    private var accessTokenExpiry: Date?

    private let refreshTokenKey = "wearmemory.google.refresh_token"
    private let pendingVerifierKey = "wearmemory.google.pending_pkce_verifier"
    private let pendingStateKey = "wearmemory.google.pending_oauth_state"
    private let queueDefaultsKey = "drive.oauth.pending.v1"
    private let pickedFoldersKey = "drive.oauth.pickedFolders.v1"

    private enum PendingKind: String, Codable {
        case text
        case audio
    }

    private struct PendingItem: Codable, Equatable {
        let id: String
        let kind: PendingKind
        let path: String
    }

    override init() {
        super.init()
        try? fm.createDirectory(at: pendingAudioDirectory, withIntermediateDirectories: true)
        isAuthorized = KeychainStore.read(key: refreshTokenKey) != nil
        let picked = Set(defaults.stringArray(forKey: pickedFoldersKey) ?? [])
        foldersAuthorized = picked.contains(Self.textFolderID) && picked.contains(Self.audioFolderID)
        updatePublishedStatus()
        updatePendingCount()

        monitor.pathUpdateHandler = { [weak self] path in
            guard path.status == .satisfied else { return }
            self?.flushQueue()
        }
        monitor.start(queue: monitorQueue)

        if isAuthorized && foldersAuthorized {
            verifyTargetFolders { [weak self] verified in
                if verified && self?.syncEnabled == true { self?.flushQueue() }
            }
        }
    }

    deinit {
        monitor.cancel()
    }

    var textFolderDisplay: String { "ChatGpt/Audio/Audio Lesen" }
    var audioFolderDisplay: String { "ChatGpt/Audio/Audio Hören" }

    func connect() {
        DispatchQueue.main.async {
            self.lastError = nil
            self.statusText = "Открываю Google в браузере…"
        }

        let verifier = Self.randomBase64URL(byteCount: 64)
        let challenge = Self.base64URL(Data(SHA256.hash(data: Data(verifier.utf8))))
        let state = Self.randomBase64URL(byteCount: 32)

        // The desktop/mobile Picker flow is documented by Google as a system-browser flow.
        // Persist the transient PKCE verifier/state in Keychain so the callback still works if
        // iOS suspends or terminates WearMemory while Safari is in front.
        guard KeychainStore.write(key: pendingVerifierKey, value: verifier),
              KeychainStore.write(key: pendingStateKey, value: state) else {
            KeychainStore.delete(key: pendingVerifierKey)
            KeychainStore.delete(key: pendingStateKey)
            setError("Не удалось сохранить временные данные OAuth")
            return
        }
        currentVerifier = verifier
        currentState = state

        // Official Google Picker desktop/mobile OAuth flow. prompt=consent and
        // trigger_onepick=true are required. file_ids restricts the picker to the two known
        // destination folders and allow_folder_selection enables selecting folder objects.
        var components = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        components.queryItems = [
            URLQueryItem(name: "client_id", value: Self.clientID),
            URLQueryItem(name: "scope", value: Self.scope),
            URLQueryItem(name: "redirect_uri", value: Self.redirectURI),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "access_type", value: "offline"),
            URLQueryItem(name: "prompt", value: "consent"),
            URLQueryItem(name: "trigger_onepick", value: "true"),
            URLQueryItem(name: "allow_multiple", value: "true"),
            URLQueryItem(name: "allow_folder_selection", value: "true"),
            URLQueryItem(name: "mimetypes", value: "application/vnd.google-apps.folder"),
            URLQueryItem(name: "file_ids", value: [Self.textFolderID, Self.audioFolderID].joined(separator: ",")),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: state)
        ]

        guard let url = components.url else {
            clearPendingOAuth()
            setError("Не удалось создать URL авторизации")
            return
        }

        // Open the real default browser instead of ASWebAuthenticationSession. Google documents
        // the desktop/mobile Picker as a redirect in a new browser tab / system browser.
        DispatchQueue.main.async {
            UIApplication.shared.open(url, options: [:]) { [weak self] success in
                guard let self = self else { return }
                if !success {
                    self.clearPendingOAuth()
                    self.setError("Не удалось открыть браузер для Google OAuth")
                }
            }
        }
    }

    @discardableResult
    func handleOpenURL(_ url: URL) -> Bool {
        guard url.scheme == Self.callbackScheme else { return false }
        handleOAuthCallback(url)
        return true
    }

    func disconnect() {
        clearPendingOAuth()
        accessToken = nil
        accessTokenExpiry = nil
        KeychainStore.delete(key: refreshTokenKey)
        defaults.removeObject(forKey: pickedFoldersKey)
        DispatchQueue.main.async {
            self.isAuthorized = false
            self.foldersAuthorized = false
            self.lastError = nil
            self.updatePublishedStatus()
        }
    }

    func enqueueText(_ sourceURL: URL) {
        guard syncEnabled else { return }
        workQueue.async {
            var queue = self.loadQueue()
            queue.removeAll { $0.kind == .text && URL(fileURLWithPath: $0.path).lastPathComponent == sourceURL.lastPathComponent }
            queue.append(PendingItem(id: "text:\(sourceURL.lastPathComponent):\(UUID().uuidString)", kind: .text, path: sourceURL.path))
            self.saveQueue(queue)
            self.flushQueueLocked()
        }
    }

    func enqueueAudio(_ sourceURL: URL) {
    guard syncEnabled else { return }

    // AVAudioRecorderDelegate calls this only after the M4A has been finalized.
    // Stage the file and persist the queue synchronously before returning.
    workQueue.sync {
        guard self.fm.fileExists(atPath: sourceURL.path) else {
            self.setError("Очередь Google Drive: завершённый аудиофайл не найден")
            return
        }

        let size = (try? sourceURL.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        guard size > 0 else {
            self.setError("Очередь Google Drive: завершённый аудиофайл пуст")
            return
        }

        let target = self.pendingAudioDirectory.appendingPathComponent(sourceURL.lastPathComponent)
        do {
            if self.fm.fileExists(atPath: target.path) {
                try self.fm.removeItem(at: target)
            }
            try self.fm.copyItem(at: sourceURL, to: target)
        } catch {
            self.setError("Очередь Google Drive: \(error.localizedDescription)")
            return
        }

        var queue = self.loadQueue()
        let id = "audio:\(target.lastPathComponent)"
        queue.removeAll { $0.id == id }
        queue.append(PendingItem(id: id, kind: .audio, path: target.path))
        self.saveQueue(queue)

        // Upload starts only after the durable queue entry has been persisted.
        self.flushQueueLocked()
    }
}

func flushQueue() {
        workQueue.async { self.flushQueueLocked() }
    }

    private var pendingAudioDirectory: URL {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("DrivePendingAudio", isDirectory: true)
    }

    private func handleOAuthCallback(_ url: URL) {
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
            clearPendingOAuth()
            setError("Не удалось разобрать ответ Google")
            return
        }
        let items = Dictionary(uniqueKeysWithValues: (components.queryItems ?? []).map { ($0.name, $0.value ?? "") })
        if let error = items["error"], !error.isEmpty {
            clearPendingOAuth()
            setError("Google OAuth: \(error)")
            return
        }

        let expectedState = currentState ?? KeychainStore.read(key: pendingStateKey)
        let verifier = currentVerifier ?? KeychainStore.read(key: pendingVerifierKey)

        // Google Picker desktop/mobile callbacks can omit state. If state is present, validate
        // it strictly; if it is absent, PKCE code_verifier still binds the authorization code
        // to the request created by this app.
        if let returnedState = items["state"], !returnedState.isEmpty {
            guard let expectedState = expectedState, !expectedState.isEmpty,
                  returnedState == expectedState else {
                clearPendingOAuth()
                setError("OAuth state не совпадает")
                return
            }
        }
        guard let code = items["code"], !code.isEmpty,
              let verifier = verifier, !verifier.isEmpty else {
            clearPendingOAuth()
            setError("Google не вернул authorization code")
            return
        }

        guard let rawPicked = items["picked_file_ids"], !rawPicked.isEmpty else {
            clearPendingOAuth()
            setError("Google Picker не вернул выбранные папки")
            return
        }
        let decodedPicked = rawPicked.removingPercentEncoding ?? rawPicked
        let pickedIDs = decodedPicked
            .split(separator: ",")
            .map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        let pickedSet = Set(pickedIDs)
        guard pickedSet.contains(Self.textFolderID), pickedSet.contains(Self.audioFolderID) else {
            clearPendingOAuth()
            setError("Нужно выбрать обе папки: Audio Lesen и Audio Hören")
            return
        }

        clearPendingOAuth()
        exchangeAuthorizationCode(code, verifier: verifier, pickedFolderIDs: pickedIDs)
    }

    private func exchangeAuthorizationCode(_ code: String, verifier: String, pickedFolderIDs: [String]) {
        DispatchQueue.main.async { self.statusText = "Получаю токен…" }
        let fields = [
            "code": code,
            "client_id": Self.clientID,
            "code_verifier": verifier,
            "grant_type": "authorization_code",
            "redirect_uri": Self.redirectURI
        ]
        tokenRequest(fields: fields) { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .failure(let error):
                self.setError("Обмен OAuth-кода: \(error.localizedDescription)")
            case .success(let token):
                guard let refresh = token.refreshToken, !refresh.isEmpty else {
                    self.setError("Google не вернул refresh_token")
                    return
                }
                guard KeychainStore.write(key: self.refreshTokenKey, value: refresh) else {
                    self.setError("Не удалось сохранить refresh_token в Keychain")
                    return
                }
                self.accessToken = token.accessToken
                self.accessTokenExpiry = Date().addingTimeInterval(TimeInterval(max(60, token.expiresIn - 60)))
                DispatchQueue.main.async {
                    self.isAuthorized = true
                    self.statusText = "Проверяю доступ к папкам…"
                    self.updatePublishedStatus()
                }
                // Persist Picker authorization only after Drive API confirms access to both
                // selected folders with the newly issued drive.file token.
                self.verifyTargetFolders { verified in
                    if verified {
                        let normalized = Array(Set(pickedFolderIDs))
                        self.defaults.set(normalized, forKey: self.pickedFoldersKey)
                        self.flushQueue()
                    }
                }
            }
        }
    }

    private struct TokenResponse: Decodable {
        let accessToken: String
        let expiresIn: Int
        let refreshToken: String?

        enum CodingKeys: String, CodingKey {
            case accessToken = "access_token"
            case expiresIn = "expires_in"
            case refreshToken = "refresh_token"
        }
    }

    private func tokenRequest(fields: [String: String], completion: @escaping (Result<TokenResponse, Error>) -> Void) {
        var request = URLRequest(url: URL(string: "https://oauth2.googleapis.com/token")!)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpBody = Self.formEncoded(fields).data(using: .utf8)
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error { completion(.failure(error)); return }
            guard let http = response as? HTTPURLResponse, let data = data else {
                completion(.failure(Self.httpError("Пустой ответ OAuth"))); return
            }
            guard (200..<300).contains(http.statusCode) else {
                let text = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
                completion(.failure(Self.httpError(text))); return
            }
            do {
                completion(.success(try JSONDecoder().decode(TokenResponse.self, from: data)))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }

    private func withAccessToken(_ completion: @escaping (Result<String, Error>) -> Void) {
        if let token = accessToken, let expiry = accessTokenExpiry, expiry > Date() {
            completion(.success(token))
            return
        }
        guard let refresh = KeychainStore.read(key: refreshTokenKey) else {
            completion(.failure(Self.httpError("Google Drive не подключён")))
            return
        }
        tokenRequest(fields: [
            "client_id": Self.clientID,
            "refresh_token": refresh,
            "grant_type": "refresh_token"
        ]) { [weak self] result in
            switch result {
            case .failure(let error): completion(.failure(error))
            case .success(let token):
                self?.accessToken = token.accessToken
                self?.accessTokenExpiry = Date().addingTimeInterval(TimeInterval(max(60, token.expiresIn - 60)))
                completion(.success(token.accessToken))
            }
        }
    }

    private func verifyTargetFolders(completion: @escaping (Bool) -> Void) {
        withAccessToken { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .failure(let error):
                DispatchQueue.main.async {
                    self.foldersAuthorized = false
                    self.lastError = "Проверка папок: \(error.localizedDescription)"
                    self.updatePublishedStatus()
                    completion(false)
                }

            case .success(let token):
                let ids = [Self.textFolderID, Self.audioFolderID]
                let group = DispatchGroup()
                var ok = true
                let lock = NSLock()

                for id in ids {
                    group.enter()
                    var request = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(id)?fields=id,name,mimeType")!)
                    request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                    URLSession.shared.dataTask(with: request) { _, response, _ in
                        let http = response as? HTTPURLResponse
                        let success = http.map { (200..<300).contains($0.statusCode) } ?? false
                        lock.lock()
                        if !success { ok = false }
                        lock.unlock()
                        group.leave()
                    }.resume()
                }

                group.notify(queue: self.workQueue) {
                    DispatchQueue.main.async {
                        self.foldersAuthorized = ok
                        self.lastError = ok ? nil : "Нет доступа к папкам Audio Lesen / Audio Hören на этом Google-аккаунте. Выберите обе папки в Google Picker."
                        self.updatePublishedStatus()
                        // completion is intentionally called only after all @Published state is
                        // updated on the main thread, preventing flushQueue() from seeing stale state.
                        completion(ok)
                    }
                }
            }
        }
    }

    private func flushQueueLocked() {
        guard syncEnabled, isAuthorized, foldersAuthorized, !isFlushing else { return }
        var queue = loadQueue()
        guard !queue.isEmpty else { updatePendingCount(); return }
        isFlushing = true
        process(queue: queue, index: 0)
    }

    private func process(queue: [PendingItem], index: Int) {
        if index >= queue.count {
            isFlushing = false
            updatePendingCount()
            return
        }
        let item = queue[index]
        let url = URL(fileURLWithPath: item.path)
        guard fm.fileExists(atPath: url.path) else {
            removePending(id: item.id)
            process(queue: loadQueue(), index: 0)
            return
        }

        withAccessToken { [weak self] tokenResult in
            guard let self = self else { return }
            switch tokenResult {
            case .failure(let error):
                self.isFlushing = false
                self.setError("Google Drive: \(error.localizedDescription)")
            case .success(let token):
                self.upload(item: item, url: url, accessToken: token) { result in
                    self.workQueue.async {
                        switch result {
                        case .failure(let error):
                            self.isFlushing = false
                            self.setError("Google Drive: \(error.localizedDescription)")
                        case .success:
                            self.removePending(id: item.id)
                            if item.kind == .audio { try? self.fm.removeItem(at: url) }
                            self.process(queue: self.loadQueue(), index: 0)
                        }
                    }
                }
            }
        }
    }

    private func upload(item: PendingItem, url: URL, accessToken: String, completion: @escaping (Result<Void, Error>) -> Void) {
        do {
            let data = try Data(contentsOf: url)
            switch item.kind {
            case .audio:
                createFile(name: url.lastPathComponent, data: data, mimeType: "audio/mp4", parentID: Self.audioFolderID, accessToken: accessToken) { result in
                    completion(result.map { _ in () })
                }
            case .text:
                let mappingKey = "drive.oauth.textRemote.\(url.lastPathComponent)"
                if let remoteID = defaults.string(forKey: mappingKey) {
                    updateFile(fileID: remoteID, data: data, mimeType: "text/plain; charset=utf-8", accessToken: accessToken) { [weak self] result in
                        switch result {
                        case .success: completion(.success(()))
                        case .failure(let error as DriveHTTPError) where error.statusCode == 404:
                            self?.defaults.removeObject(forKey: mappingKey)
                            self?.createText(url: url, data: data, mappingKey: mappingKey, accessToken: accessToken, completion: completion)
                        case .failure(let error): completion(.failure(error))
                        }
                    }
                } else {
                    createText(url: url, data: data, mappingKey: mappingKey, accessToken: accessToken, completion: completion)
                }
            }
        } catch {
            completion(.failure(error))
        }
    }

    private func createText(url: URL, data: Data, mappingKey: String, accessToken: String, completion: @escaping (Result<Void, Error>) -> Void) {
        createFile(name: url.lastPathComponent, data: data, mimeType: "text/plain; charset=utf-8", parentID: Self.textFolderID, accessToken: accessToken) { [weak self] result in
            switch result {
            case .failure(let error): completion(.failure(error))
            case .success(let remoteID):
                self?.defaults.set(remoteID, forKey: mappingKey)
                completion(.success(()))
            }
        }
    }

    private func createFile(name: String, data: Data, mimeType: String, parentID: String, accessToken: String, completion: @escaping (Result<String, Error>) -> Void) {
        let boundary = "WearMemory-\(UUID().uuidString)"
        let metadata: [String: Any] = ["name": name, "parents": [parentID]]
        guard let metadataData = try? JSONSerialization.data(withJSONObject: metadata) else {
            completion(.failure(Self.httpError("Не удалось создать metadata"))); return
        }
        var body = Data()
        body.append("--\(boundary)\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".data(using: .utf8)!)
        body.append(metadataData)
        body.append("\r\n--\(boundary)\r\nContent-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        body.append(data)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)

        var request = URLRequest(url: URL(string: "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id")!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/related; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error { completion(.failure(error)); return }
            guard let http = response as? HTTPURLResponse, let data = data else {
                completion(.failure(Self.httpError("Пустой ответ Drive"))); return
            }
            guard (200..<300).contains(http.statusCode) else {
                completion(.failure(DriveHTTPError(statusCode: http.statusCode, body: String(data: data, encoding: .utf8) ?? ""))); return
            }
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let id = json["id"] as? String else {
                completion(.failure(Self.httpError("Drive не вернул file id"))); return
            }
            completion(.success(id))
        }.resume()
    }

    private func updateFile(fileID: String, data: Data, mimeType: String, accessToken: String, completion: @escaping (Result<Void, Error>) -> Void) {
        var request = URLRequest(url: URL(string: "https://www.googleapis.com/upload/drive/v3/files/\(fileID)?uploadType=media")!)
        request.httpMethod = "PATCH"
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue(mimeType, forHTTPHeaderField: "Content-Type")
        request.httpBody = data
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error { completion(.failure(error)); return }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(Self.httpError("Пустой ответ Drive"))); return
            }
            guard (200..<300).contains(http.statusCode) else {
                completion(.failure(DriveHTTPError(statusCode: http.statusCode, body: data.flatMap { String(data: $0, encoding: .utf8) } ?? ""))); return
            }
            completion(.success(()))
        }.resume()
    }

    private func loadQueue() -> [PendingItem] {
        guard let data = defaults.data(forKey: queueDefaultsKey),
              let items = try? JSONDecoder().decode([PendingItem].self, from: data) else { return [] }
        return items
    }

    private func saveQueue(_ items: [PendingItem]) {
        if let data = try? JSONEncoder().encode(items) { defaults.set(data, forKey: queueDefaultsKey) }
        updatePendingCount(items.count)
    }

    private func removePending(id: String) {
        var queue = loadQueue()
        queue.removeAll { $0.id == id }
        saveQueue(queue)
    }

    private func updatePendingCount(_ explicit: Int? = nil) {
        let count = explicit ?? loadQueue().count
        DispatchQueue.main.async { self.pendingCount = count }
    }

    private func updatePublishedStatus() {
        if !isAuthorized {
            statusText = "Не подключено"
        } else if !foldersAuthorized {
            statusText = "Нет доступа к папкам Drive"
        } else if syncEnabled {
            statusText = pendingCount > 0 ? "Синхронизация · очередь \(pendingCount)" : "Подключено"
        } else {
            statusText = "Подключено · синхронизация выключена"
        }
    }

    private func clearPendingOAuth() {
        currentVerifier = nil
        currentState = nil
        KeychainStore.delete(key: pendingVerifierKey)
        KeychainStore.delete(key: pendingStateKey)
    }

    private func setError(_ message: String) {
        DispatchQueue.main.async {
            self.lastError = message
            self.statusText = "Ошибка"
        }
    }

    private struct DriveHTTPError: LocalizedError {
        let statusCode: Int
        let body: String
        var errorDescription: String? {
            let trimmed = body.replacingOccurrences(of: "\n", with: " ")
            return "HTTP \(statusCode): \(String(trimmed.prefix(220)))"
        }
    }

    private static func httpError(_ text: String) -> Error {
        NSError(domain: "WearMemory.GoogleDrive", code: -1, userInfo: [NSLocalizedDescriptionKey: text])
    }

    private static func randomBase64URL(byteCount: Int) -> String {
        var bytes = [UInt8](repeating: 0, count: byteCount)
        let status = bytes.withUnsafeMutableBytes { rawBuffer in
            SecRandomCopyBytes(kSecRandomDefault, byteCount, rawBuffer.baseAddress!)
        }
        if status != errSecSuccess {
            return UUID().uuidString.replacingOccurrences(of: "-", with: "") + UUID().uuidString.replacingOccurrences(of: "-", with: "")
        }
        return base64URL(Data(bytes))
    }

    private static func base64URL(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    private static func formEncoded(_ fields: [String: String]) -> String {
        fields.map { key, value in
            "\(urlEncode(key))=\(urlEncode(value))"
        }.sorted().joined(separator: "&")
    }

    private static func urlEncode(_ value: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
    }
}

private enum KeychainStore {
    static func write(key: String, value: String) -> Bool {
        guard let data = value.data(using: .utf8) else { return false }
        delete(key: key)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "local.pavel.WearMemory.GoogleDrive",
            kSecAttrAccount as String: key,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        return SecItemAdd(query as CFDictionary, nil) == errSecSuccess
    }

    static func read(key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "local.pavel.WearMemory.GoogleDrive",
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(key: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "local.pavel.WearMemory.GoogleDrive",
            kSecAttrAccount as String: key
        ]
        SecItemDelete(query as CFDictionary)
    }
}
