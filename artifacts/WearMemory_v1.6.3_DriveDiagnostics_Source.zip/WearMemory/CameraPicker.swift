import SwiftUI
import UIKit
import AVFoundation
import UniformTypeIdentifiers

struct CameraPicker: UIViewControllerRepresentable {
    let mode: MediaCaptureMode
    let onCaptured: (PendingMedia) -> Void
    let onCancel: () -> Void

    func makeUIViewController(context: Context) -> UIViewController {
        switch mode {
        case .photo:
            let picker = UIImagePickerController()
            picker.delegate = context.coordinator
            picker.sourceType = .camera
            picker.allowsEditing = false
            picker.mediaTypes = [UTType.image.identifier]
            picker.cameraCaptureMode = .photo
            return picker

        case .video:
            let vc = SilentVideoCaptureViewController()
            vc.onFinished = { url in
                if let url = url {
                    onCaptured(.video(url))
                } else {
                    onCancel()
                }
            }
            return vc
        }
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: CameraPicker

        init(_ parent: CameraPicker) {
            self.parent = parent
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true) {
                self.parent.onCancel()
            }
        }

        func imagePickerController(
            _ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]
        ) {
            guard let image = info[.originalImage] as? UIImage else {
                picker.dismiss(animated: true) { self.parent.onCancel() }
                return
            }

            picker.dismiss(animated: true) {
                self.parent.onCaptured(.photo(image))
            }
        }
    }
}


// MARK: - Silent video recorder
// IMPORTANT: this capture session adds ONLY a camera/video input.
// No AVCaptureDevice.default(for: .audio) is ever added, so the MOV has no audio track.

final class SilentVideoCaptureViewController: UIViewController, AVCaptureFileOutputRecordingDelegate {
    var onFinished: ((URL?) -> Void)?

    private let session = AVCaptureSession()
    private let movieOutput = AVCaptureMovieFileOutput()
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private var recordButton: UIButton!
    private var cancelButton: UIButton!
    private var outputURL: URL?
    private var isCancelling = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        configureSession()
        configurePreview()
        configureControls()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.global(qos: .userInitiated).async {
            self.session.startRunning()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if session.isRunning {
            session.stopRunning()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
        recordButton?.frame = CGRect(
            x: (view.bounds.width - 78) / 2,
            y: view.bounds.height - 110,
            width: 78,
            height: 78
        )
        cancelButton?.frame = CGRect(
            x: 20,
            y: view.bounds.height - 100,
            width: 90,
            height: 50
        )
    }

    private func configureSession() {
        session.beginConfiguration()
        session.sessionPreset = .high

        guard let camera = AVCaptureDevice.default(
            .builtInWideAngleCamera,
            for: .video,
            position: .back
        ),
        let videoInput = try? AVCaptureDeviceInput(device: camera),
        session.canAddInput(videoInput)
        else {
            session.commitConfiguration()
            return
        }

        session.addInput(videoInput)

        // Deliberately DO NOT add an audio input.
        // Result: video file has no microphone/sound track.

        if session.canAddOutput(movieOutput) {
            session.addOutput(movieOutput)
        }

        session.commitConfiguration()
    }

    private func configurePreview() {
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.insertSublayer(previewLayer, at: 0)
    }

    private func configureControls() {
        recordButton = UIButton(type: .custom)
        recordButton.backgroundColor = .systemRed
        recordButton.layer.cornerRadius = 39
        recordButton.layer.borderWidth = 5
        recordButton.layer.borderColor = UIColor.white.cgColor
        recordButton.addTarget(self, action: #selector(toggleRecording), for: .touchUpInside)
        view.addSubview(recordButton)

        cancelButton = UIButton(type: .system)
        cancelButton.setTitle("Отмена", for: .normal)
        cancelButton.setTitleColor(.white, for: .normal)
        cancelButton.titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
        cancelButton.addTarget(self, action: #selector(cancelCapture), for: .touchUpInside)
        view.addSubview(cancelButton)
    }

    @objc private func toggleRecording() {
        if movieOutput.isRecording {
            movieOutput.stopRecording()
            recordButton.backgroundColor = .systemRed
            return
        }

        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("WearMemory-silent-\(UUID().uuidString).mov")
        try? FileManager.default.removeItem(at: url)
        outputURL = url

        movieOutput.startRecording(to: url, recordingDelegate: self)
        recordButton.backgroundColor = .white
    }

    @objc private func cancelCapture() {
        if movieOutput.isRecording {
            // Stopping is async — the actual cleanup + onFinished(nil) happens in
            // fileOutput(...) once recording has really finished. Calling dismiss/onFinished
            // here too would fire the callback twice (once with a nil url, once with a url
            // pointing at a file we already deleted).
            isCancelling = true
            movieOutput.stopRecording()
            return
        }
        dismiss(animated: true) {
            self.onFinished?(nil)
        }
    }

    func fileOutput(
        _ output: AVCaptureFileOutput,
        didFinishRecordingTo outputFileURL: URL,
        from connections: [AVCaptureConnection],
        error: Error?
    ) {
        let cancelled = isCancelling
        isCancelling = false

        if cancelled || error != nil {
            try? FileManager.default.removeItem(at: outputFileURL)
            dismiss(animated: true) {
                self.onFinished?(nil)
            }
            return
        }

        dismiss(animated: true) {
            self.onFinished?(outputFileURL)
        }
    }
}
