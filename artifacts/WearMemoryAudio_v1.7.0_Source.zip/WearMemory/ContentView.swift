import SwiftUI
import Speech

struct ContentView: View {
    @EnvironmentObject var model: AppModel

    @State private var showShare = false
    @State private var captureMode: MediaCaptureMode?
    @State private var pendingMedia: PendingMedia?
    @State private var mediaError: String?
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            homeView
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Главная")
                }
                .tag(0)

            filesView
                .tabItem {
                    Image(systemName: "folder.fill")
                    Text("Файлы")
                }
                .tag(1)

            recognitionView
                .tabItem {
                    Image(systemName: "waveform.and.mic")
                    Text("Распознавание")
                }
                .tag(2)

            settingsView
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text("Настройки")
                }
                .tag(3)
        }
        .accentColor(.blue)
        .preferredColorScheme(.dark)
        .onAppear { model.requestPermissions() }
        .sheet(isPresented: $showShare) {
            ShareSheet(items: [model.logs.todayTextURL()])
        }
        .sheet(item: $captureMode) { mode in
            CameraPicker(
                mode: mode,
                onCaptured: { captured in
                    captureMode = nil
                    pendingMedia = captured
                },
                onCancel: {
                    captureMode = nil
                    model.endMediaCaptureWithoutSave()
                }
            )
        }
        .sheet(
            isPresented: Binding(
                get: { pendingMedia != nil },
                set: { if !$0 { pendingMedia = nil } }
            )
        ) {
            if let pending = pendingMedia {
                MediaConfirmationView(
                    media: pending,
                    onSave: {
                        do {
                            _ = try model.savePendingMedia(pending)
                            pendingMedia = nil
                        } catch {
                            mediaError = error.localizedDescription
                        }
                    },
                    onDiscard: {
                        model.discardPendingMedia(pending)
                        pendingMedia = nil
                    }
                )
            }
        }
        .alert(
            "Ошибка сохранения",
            isPresented: Binding(
                get: { mediaError != nil },
                set: { if !$0 { mediaError = nil } }
            )
        ) {
            Button("OK", role: .cancel) { mediaError = nil }
        } message: {
            Text(mediaError ?? "")
        }
    }

    private var homeView: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("WearMemory Audio")
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .padding(.top, 8)

                    sectionTitle("Состояние")
                    statusCard

                    sectionTitle("Запись")
                    recordingCard

                    sectionTitle("Хранение в Google Drive")
                    storageCard

                    sectionTitle("Фото и видео")
                    mediaCard

                    sectionTitle("ChatGPT без API")
                    chatGPTCard

                    sectionTitle("Последние записи")
                    recentAudioCard

                    if !model.logs.entries.isEmpty {
                        sectionTitle("Последний распознанный текст")
                        transcriptCard
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 26)
            }
        }
    }

    private var filesView: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Файлы")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .padding(.top, 10)

                    sectionTitle("Google Drive")
                    storageCard

                    sectionTitle("Аудиобуфер на iPod")
                    VStack(alignment: .leading, spacing: 10) {
                        infoRow(icon: "waveform", title: "Фрагментов", value: "\(model.audio.segmentCount) / 480", tint: .blue)
                        infoRow(icon: "externaldrive.fill", title: "Размер", value: formatBytes(model.audio.bufferBytes), tint: .purple)
                    }
                    .cardStyle()

                    sectionTitle("Последние аудиофайлы")
                    recentAudioCard

                    sectionTitle("Текстовый журнал")
                    Button {
                        showShare = true
                    } label: {
                        HStack {
                            Image(systemName: "doc.text.fill")
                                .font(.title2)
                                .foregroundColor(.blue)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("Экспортировать дневной .txt")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                Text("Системное меню iOS")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Image(systemName: "square.and.arrow.up")
                                .foregroundColor(.blue)
                        }
                        .padding(14)
                        .cardStyle()
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 26)
            }
        }
    }

    private var recognitionView: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Распознавание")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .padding(.top, 10)

                    VStack(spacing: 0) {
                        compactSettingRow(icon: "globe", title: "Язык", tint: .blue) {
                            Picker("", selection: $model.language) {
                                ForEach(TranscriptionLanguage.allCases) { lang in
                                    Text(lang.title).tag(lang)
                                }
                            }
                            .pickerStyle(.menu)
                        }

                        Divider().background(Color.white.opacity(0.08))

                        compactSettingRow(icon: "doc.text.fill", title: "Дневной текстовый журнал", tint: .blue) {
                            Toggle("", isOn: $model.transcriptionEnabled)
                                .labelsHidden()
                        }

                        Divider().background(Color.white.opacity(0.08))

                        compactSettingRow(icon: "brain.head.profile", title: "Только локальное распознавание", tint: .blue) {
                            Toggle("", isOn: $model.onDeviceOnly)
                                .labelsHidden()
                        }
                    }
                    .cardStyle()

                    sectionTitle("Speech")
                    VStack(alignment: .leading, spacing: 10) {
                        infoRow(icon: "bubble.left.and.waveform.fill", title: "Состояние", value: model.transcription.statusText, tint: .purple)
                        infoRow(icon: "iphone", title: "On-device", value: model.transcription.supportsOnDevice ? "поддерживается" : "не подтверждено", tint: .green)
                    }
                    .cardStyle()

                    sectionTitle("Последние записи")
                    transcriptCard
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 26)
            }
        }
    }

    private var settingsView: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Настройки")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .padding(.top, 10)

                    sectionTitle("Устройство")
                    VStack(alignment: .leading, spacing: 10) {
                        infoRow(icon: "mic.fill", title: "Микрофон", value: model.audio.inputName, tint: .green)
                        if model.batteryLevel >= 0 {
                            infoRow(icon: "battery.50", title: "Батарея", value: "\(Int(model.batteryLevel * 100))%", tint: .green)
                        }
                        infoRow(icon: "clock.fill", title: "Аудиофрагмент", value: "3 минуты", tint: .orange)
                        infoRow(icon: "archivebox.fill", title: "24 часа", value: "до 480 фрагментов", tint: .blue)
                    }
                    .cardStyle()

                    sectionTitle("Google Drive")
                    GoogleDriveSettingsCard(driveSync: model.driveSync)

                    sectionTitle("Назначение")
                    storageCard
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 26)
            }
        }
    }

    private var statusCard: some View {
        HStack(spacing: 2) {
            statusItem(
                icon: model.audio.isRecording ? "record.circle.fill" : "stop.circle.fill",
                iconColor: model.audio.isRecording ? .red : .gray,
                title: "Запись",
                value: model.audio.isRecording ? "идёт" : "стоп",
                valueColor: model.audio.isRecording ? .green : .secondary
            )

            statusItem(
                icon: "mic.fill",
                iconColor: .green,
                title: "Микрофон",
                value: model.audio.inputName == "—" ? "—" : "активен",
                valueColor: model.audio.inputName == "—" ? .secondary : .green
            )

            statusItem(
                icon: "externaldrive.fill",
                iconColor: .blue,
                title: "Буфер",
                value: "\(model.audio.segmentCount)/480",
                valueColor: .blue
            )

            statusItem(
                icon: "bubble.left.fill",
                iconColor: .purple,
                title: "Speech",
                value: speechShortStatus,
                valueColor: speechShortStatus == "готов" ? .green : .secondary
            )
        }
        .padding(.vertical, 14)
        .padding(.horizontal, 4)
        .cardStyle()
    }

    private var recordingCard: some View {
        HStack(spacing: 12) {
            Button {
                if model.audio.isRecording { model.audio.stop() }
                else { model.audio.start() }
            } label: {
                VStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(model.audio.isRecording ? Color.red : Color.blue)
                            .frame(width: 112, height: 112)
                            .shadow(color: (model.audio.isRecording ? Color.red : Color.blue).opacity(0.55), radius: 14)
                        Circle()
                            .stroke(Color.white.opacity(0.18), lineWidth: 2)
                            .frame(width: 126, height: 126)
                        Image(systemName: model.audio.isRecording ? "stop.fill" : "record.circle")
                            .font(.system(size: 38, weight: .bold))
                            .foregroundColor(.white)
                    }
                    Text(model.audio.isRecording ? "Остановить запись" : "Начать запись")
                        .font(.headline)
                        .foregroundColor(model.audio.isRecording ? .red : .blue)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                }
            }
            .buttonStyle(.plain)
            .frame(width: 135)

            VStack(spacing: 0) {
                Button {
                    selectedTab = 2
                } label: {
                    settingRow(icon: "doc.text.fill", title: "Дневной текстовый журнал", subtitle: model.transcriptionEnabled ? "Включён" : "Выключен", tint: .blue)
                }
                .buttonStyle(.plain)

                Divider().background(Color.white.opacity(0.08))

                Button {
                    selectedTab = 2
                } label: {
                    settingRow(icon: "globe", title: "Язык", subtitle: model.language.title, tint: .blue)
                }
                .buttonStyle(.plain)

                Divider().background(Color.white.opacity(0.08))

                HStack(spacing: 9) {
                    Image(systemName: "brain.head.profile")
                        .font(.title2)
                        .foregroundColor(.blue)
                        .frame(width: 30)
                    Text("Только локальное\nраспознавание")
                        .font(.subheadline)
                        .foregroundColor(.white)
                    Spacer(minLength: 4)
                    Toggle("", isOn: $model.onDeviceOnly)
                        .labelsHidden()
                        .scaleEffect(0.86)
                }
                .padding(.vertical, 10)
                .padding(.horizontal, 8)
            }
        }
        .padding(12)
        .cardStyle()
    }

    private var storageCard: some View {
        GoogleDriveStorageCard(driveSync: model.driveSync)
    }

    private var mediaCard: some View {
        HStack(spacing: 0) {
            mediaTile(icon: "camera.fill", title: "Камера", tint: .cyan) {
                model.beginMediaCapture()
                captureMode = .photo
            }

            mediaTile(icon: "photo.fill.on.rectangle.fill", title: "Фото", tint: .blue) {
                model.beginMediaCapture()
                captureMode = .photo
            }

            mediaTile(icon: "video.fill", title: "Видео", tint: .purple) {
                model.beginMediaCapture()
                captureMode = .video
            }

            mediaTile(icon: "folder.fill", title: "Файлы", tint: .green) {
                selectedTab = 1
            }
        }
        .padding(.vertical, 14)
        .cardStyle()
    }

    private var chatGPTCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "message.fill")
                .font(.system(size: 34))
                .foregroundColor(.green)

            VStack(alignment: .leading, spacing: 4) {
                Text("Последние 24 часа")
                    .font(.headline)
                    .foregroundColor(.white)
                Text("Копировать текст и открыть ChatGPT")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Button("Открыть чат") {
                model.copyLast24HoursAndOpenChatGPT()
            }
            .font(.subheadline.weight(.semibold))
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
        }
        .padding(14)
        .cardStyle()
    }

    private var recentAudioCard: some View {
        VStack(spacing: 0) {
            if model.audio.recentSegments.isEmpty {
                HStack {
                    Image(systemName: "waveform")
                        .foregroundColor(.blue)
                    Text("Пока нет завершённых аудиофрагментов")
                        .foregroundColor(.secondary)
                    Spacer()
                }
                .padding(14)
            } else {
                ForEach(Array(model.audio.recentSegments.prefix(6).enumerated()), id: \.element.id) { index, item in
                    if index > 0 {
                        Divider().background(Color.white.opacity(0.08))
                    }
                    HStack(spacing: 10) {
                        Image(systemName: "doc.badge.waveform.fill")
                            .font(.title2)
                            .foregroundColor(.cyan)
                            .frame(width: 28)

                        VStack(alignment: .leading, spacing: 3) {
                            Text(item.fileName)
                                .font(.subheadline.weight(.semibold))
                                .foregroundColor(.white)
                                .lineLimit(1)
                            Text(timeString(item.createdAt))
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }

                        Spacer()

                        Text(durationString(item.duration))
                            .font(.caption.monospacedDigit())
                            .foregroundColor(.secondary)

                        Text(formatBytes(item.sizeBytes))
                            .font(.caption.monospacedDigit())
                            .foregroundColor(.secondary)
                            .frame(minWidth: 52, alignment: .trailing)

                        Button {
                            model.audio.togglePlayback(item.url)
                        } label: {
                            Image(systemName: model.audio.isPlaying(item.url) ? "stop.circle.fill" : "play.circle.fill")
                                .font(.title2)
                                .foregroundColor(model.audio.isPlaying(item.url) ? .red : .blue)
                                .frame(width: 30, height: 30)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(model.audio.isPlaying(item.url) ? "Остановить" : "Воспроизвести")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                }
            }
        }
        .cardStyle()
    }

    private var transcriptCard: some View {
        VStack(spacing: 0) {
            if model.logs.entries.isEmpty {
                HStack {
                    Image(systemName: "text.bubble")
                        .foregroundColor(.purple)
                    Text("Пока нет распознанного текста")
                        .foregroundColor(.secondary)
                    Spacer()
                }
                .padding(14)
            } else {
                ForEach(model.logs.entries.suffix(5).reversed()) { entry in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(timeString(entry.startedAt))
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(entry.text)
                            .font(.subheadline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding(12)
                    Divider().background(Color.white.opacity(0.08))
                }
            }
        }
        .cardStyle()
    }

    private var speechShortStatus: String {
        switch model.transcription.statusText {
        case "Не запущено": return "—"
        case "Ожидание речи": return "готов"
        default:
            if model.transcription.statusText.hasPrefix("Распознаю") { return "работает" }
            return "статус"
        }
    }

    private func sectionTitle(_ text: String) -> some View {
        Text(text)
            .font(.title3.weight(.bold))
            .foregroundColor(Color.white.opacity(0.78))
            .padding(.leading, 4)
    }

    private func statusItem(icon: String, iconColor: Color, title: String, value: String, valueColor: Color) -> some View {
        VStack(spacing: 7) {
            Image(systemName: icon)
                .font(.system(size: 26, weight: .semibold))
                .foregroundColor(iconColor)
                .frame(height: 30)
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundColor(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Text(value)
                .font(.caption2.weight(.semibold))
                .foregroundColor(valueColor)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity)
    }

    private func settingRow(icon: String, title: String, subtitle: String, tint: Color) -> some View {
        HStack(spacing: 9) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(tint)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.white)
                    .lineLimit(2)
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.blue)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 8)
    }

    private func compactSettingRow<Accessory: View>(icon: String, title: String, tint: Color, @ViewBuilder accessory: () -> Accessory) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(tint)
                .frame(width: 30)
            Text(title)
                .font(.subheadline)
                .foregroundColor(.white)
            Spacer()
            accessory()
        }
        .padding(13)
    }

    private func storageRow(icon: String, iconColor: Color, label: String, status: String, path: String, buttonTitle: String, action: @escaping () -> Void) -> some View {
        HStack(spacing: 10) {
            VStack(spacing: 5) {
                Image(systemName: icon)
                    .font(.system(size: 32))
                    .foregroundColor(iconColor)
                Text(icon.contains("doc") ? "TXT" : "Аудио")
                    .font(.caption2)
                    .foregroundColor(.white)
            }
            .frame(width: 52)

            VStack(alignment: .leading, spacing: 4) {
                Text(label)
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.white)
                Text(status)
                    .font(.caption)
                    .foregroundColor(status == "Выбрана папка" ? .green : .orange)
                Text(path)
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }

            Spacer(minLength: 6)

            Button(action: action) {
                Text(buttonTitle)
                    .font(.caption.weight(.semibold))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 9)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .buttonStyle(.plain)
        }
        .padding(12)
    }

    private func mediaTile(icon: String, title: String, tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundColor(tint)
                Text(title)
                    .font(.caption)
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }

    private func infoRow(icon: String, title: String, value: String, tint: Color) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .foregroundColor(tint)
                .frame(width: 24)
            Text(title)
                .foregroundColor(.white)
            Spacer()
            Text(value)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.trailing)
        }
        .font(.subheadline)
        .padding(.horizontal, 13)
        .padding(.vertical, 4)
    }

    private func timeString(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f.string(from: date)
    }

    private func durationString(_ seconds: TimeInterval) -> String {
        guard seconds.isFinite, seconds > 0 else { return "--:--" }
        let total = Int(seconds.rounded())
        return String(format: "%02d:%02d", total / 60, total % 60)
    }

    private func formatBytes(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
}


private struct GoogleDriveSettingsCard: View {
    @ObservedObject var driveSync: GoogleDriveSync

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: isReady ? "checkmark.icloud.fill" : "icloud.and.arrow.up.fill")
                    .font(.title2)
                    .foregroundColor(isReady ? .green : .blue)
                    .frame(width: 30)
                VStack(alignment: .leading, spacing: 3) {
                    Text("OAuth 2.0 · Google Drive API")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text(driveSync.statusText)
                        .font(.caption)
                        .foregroundColor(isReady ? .green : .orange)
                }
                Spacer()
            }
            .padding(14)

            Divider().background(Color.white.opacity(0.08))

            HStack {
                Image(systemName: "arrow.triangle.2.circlepath")
                    .foregroundColor(.blue)
                    .frame(width: 30)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Автосинхронизация")
                        .foregroundColor(.white)
                    Text("Очередь: \(driveSync.pendingCount)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
                Toggle("", isOn: $driveSync.syncEnabled)
                    .labelsHidden()
            }
            .padding(14)

            Divider().background(Color.white.opacity(0.08))
            folderSetting(icon: "doc.text.fill", tint: .purple, title: "TXT → Audio Lesen", path: driveSync.textFolderDisplay)
            Divider().background(Color.white.opacity(0.08))
            folderSetting(icon: "music.note", tint: .green, title: "Аудио → Audio Hören", path: driveSync.audioFolderDisplay)
            Divider().background(Color.white.opacity(0.08))

            HStack(spacing: 10) {
                Button(isReady ? "Переподключить" : "Подключить Google Drive") {
                    driveSync.connect()
                }
                .buttonStyle(.borderedProminent)

                if driveSync.isAuthorized {
                    Button("Отключить", role: .destructive) {
                        driveSync.disconnect()
                    }
                    .buttonStyle(.bordered)
                }
                Spacer()
            }
            .padding(14)

            if let error = driveSync.lastError {
                Divider().background(Color.white.opacity(0.08))
                Text(error)
                    .font(.caption)
                    .foregroundColor(.orange)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14)
            }
        }
        .cardStyle()
    }

    private var isReady: Bool {
        driveSync.isAuthorized && driveSync.foldersAuthorized
    }

    private func folderSetting(icon: String, tint: Color, title: String, path: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(tint)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .foregroundColor(.white)
                Text(driveSync.foldersAuthorized ? "Подключено · \(path)" : "Не авторизовано · \(path)")
                    .font(.caption)
                    .foregroundColor(driveSync.foldersAuthorized ? .green : .secondary)
            }
            Spacer()
        }
        .padding(14)
    }
}

private struct GoogleDriveStorageCard: View {
    @ObservedObject var driveSync: GoogleDriveSync

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: isReady ? "checkmark.icloud.fill" : "icloud.slash.fill")
                    .font(.title2)
                    .foregroundColor(isReady ? .green : .orange)
                    .frame(width: 34)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Google Drive")
                        .font(.headline)
                        .foregroundColor(.white)
                    Text(driveSync.statusText)
                        .font(.caption)
                        .foregroundColor(isReady ? .green : .orange)
                }
                Spacer()
                if driveSync.pendingCount > 0 {
                    Text("Очередь \(driveSync.pendingCount)")
                        .font(.caption.weight(.semibold))
                        .foregroundColor(.blue)
                }
            }
            .padding(14)

            Divider().background(Color.white.opacity(0.08))
            destinationRow(icon: "doc.text.fill", tint: .purple, title: "TXT → Audio Lesen", path: driveSync.textFolderDisplay)
            Divider().background(Color.white.opacity(0.08))
            destinationRow(icon: "music.note", tint: .green, title: "Аудио → Audio Hören", path: driveSync.audioFolderDisplay)

            if !isReady {
                Divider().background(Color.white.opacity(0.08))
                Button { driveSync.connect() } label: {
                    HStack {
                        Image(systemName: "person.badge.key.fill")
                        Text("Подключить Google Drive")
                            .fontWeight(.semibold)
                        Spacer()
                        Image(systemName: "chevron.right")
                    }
                    .foregroundColor(.white)
                    .padding(14)
                }
                .buttonStyle(.plain)
            }
        }
        .cardStyle()
    }

    private var isReady: Bool {
        driveSync.isAuthorized && driveSync.foldersAuthorized
    }

    private func destinationRow(icon: String, tint: Color, title: String, path: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(tint)
                .frame(width: 34)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.white)
                Text(path)
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: driveSync.foldersAuthorized ? "checkmark.circle.fill" : "circle")
                .foregroundColor(driveSync.foldersAuthorized ? .green : .secondary)
        }
        .padding(14)
    }
}

private extension View {
    func cardStyle() -> some View {
        self
            .background(Color(white: 0.105))
            .cornerRadius(16)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.white.opacity(0.035), lineWidth: 1)
            )
    }
}
